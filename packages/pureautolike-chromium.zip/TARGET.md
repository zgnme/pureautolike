# PureAutoLike Chromium Build

Use this directory with Chrome, Edge, Brave, Opera, Arc, or another Chromium browser.
This build includes the `debugger` permission so CDP-level mouse clicks are available.

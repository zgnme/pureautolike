# PureAutoLike Safari Build

Use this directory as Safari Web Extension source for Xcode or App Store Connect packaging.
Safari does not get the Chromium CDP/debugger click mode; it uses DOM fallback clicks.

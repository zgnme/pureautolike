# PureAutoLike Firefox Build

Use this directory with Firefox-compatible WebExtensions.
This build does not request `debugger`; it falls back to DOM-level clicks.
